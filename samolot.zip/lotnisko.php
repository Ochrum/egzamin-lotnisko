<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Lotnisko</title>
</head>
<body>
    <div id="baner"> <img src="samlot.png"> </div>
    
    <div id="baner2"> <h1> Przyloty</h1> </div>
    
    <div id="baner3"> <h3> przydatne linki</h3>
<a href="kwerendy.txt"> Pobierz</a> </div>
   
<div id="glowny"> 
<table>
<tr>
    <td>czas</td>
    <td>kierunek</td>
    <td>numer rejsu</td>
    <td>status</td>
    <?php
    $baza=mysqli_connect("localhost","root","","egzamin");
    $zapytanie="Select czas,kierunek,nr_rejsu,status_lotu from przyloty order by czas asc;";
    $result=mysqli_query($baza,$zapytanie);
    while($row=mysqli_fetch_array($result))
    {
        echo "<tr> <td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td>";

    }
    mysqli_close($baza);
    ?>

</tr>
</table>
</div>
<div id="stopka"> 
    <?php
    if(isset($_COOKIE['odwiedziny']))
    {
        echo "<p><i> witaj ponownie! na stronie lotniska</i></p>";
    }else
    {
echo"<p><b> dzień dobry! strona lotniska używa ciasteczek</b></p>";
setcookie('odwiedziny',1,time() + (7200));
    }
    ?>
</div>
<div id="stopka1"> Autor: Bartłomiej Ochremuk 4k</div>


</body>
</html>